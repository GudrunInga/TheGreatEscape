Please play on Fantastic Setting at 1280x720 resolution.


Game also available as a web media at:
https://product-placement.itch.io/the-great-escape?secret=tKfhkLXnHke5TaIZnRa6JaoRXM